![[Pasted image 20240426194414.png]]

Alat yang dipasang pada setiap komputer yang tergabung dalam sebuah jaringan, berfungsi sebagai penghubung kabel data yang masuk ke dalam komputer : ......  
  
NIC  
  
Jika digunakan kabel koaksial , jenis konektornya adalah ….  
  
BNC  
  
Perangkat yang berfungsi sebagai penguat sinyal dalam jaringan adalah ....  
  
Repeater  
  
Pada pemasangan kabel konektor RJ-45 dengan cara crossover, kabel berwarna hijau pada pin 2 dihubungkan pada konektor 1 pin ke ….  
  
6  
  
Jika kita menghubungkan Laptop dengan Laptop maka pemasangan pengkabelan menggunakan cara ....  
  
Crossover  
  
Topologi yang masing-masing workstation dihubungkan secara langsung ke server atau hub adalah topologi ….  
  
Star  
  
Jenis kabel yang digunakan praktikum LAN di Laboratorium Komputer sekolah adalah ....  
  
UTP (Unshielded Twisted Pair)  
  
Crimping tool adalah alat yang digunakan untuk …  
  
Penjepit RJ-45  
  
Pemasangan dalam pin konektor RJ-45 yang digunakan untuk menghubungkan satu workstation komputer dengan Hub / Switch adalah menggunakan cara ...  
  
Straight Cable  
  
Network cabel tester adalah alat yang digunakan untuk ...  
  
Menguji Kabel Jaringan  
  
Teknik pemasangan kabel untuk konektor RJ-45 adalah ...  
  
Straight and Crossover  
  
Pada pemasangan kabel konektor RJ-45 dengan cara crossover, kabel berwarna putih-orange pada pin 1 dihubungkan pada konektor 2 pin ke ….  
  
3  
  
Urutan pengkabelan dalam LAN yang susunan kabelnya sebagai berikut : Putih Orange- Orange, Putih Hijau – Biru, Putih Biru – Hijau, Putih Coklat – Coklat disebut: …..  
  
Straight  
  
Kelemahan dari topologi Ring adalah ....  
  
Jika satu komputer mengalami gangguan maka yang lain ikut terganggu  
  
Kumpulan beberapa komputer yang saling terhubung satu sama lain melalui media perantara dan bisa di gunakan secara bersama untuk mencapai suatu tujuan yang sama disebut ....  
  
Jaringan