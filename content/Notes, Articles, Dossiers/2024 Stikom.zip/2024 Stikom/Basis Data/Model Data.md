Data-data dalam basis data dikategorikan menjadi [[Model Data]]. Model data adalah representasi visual atau cetak biru yang menjelaskan pengumpulan informasi dan sistem manajemen berbagai organisasi. Model data menguraikan data yang dikumpulkan oleh bisnis, hubungan antara berbagai set data, dan metode yang akan digunakan untuk menyimpan serta menganalisis data.
Beberapa contoh model data yaitu:
1. Hubungan Entitas
2. Semantik
3. Fungsional
4. Object Based