
Database adalah koleksi data yang sistematis dan sistematis yang disimpan secara elektronik. Ini dapat berisi semua jenis data, termasuk kata, angka, gambar, video, dan file. Anda dapat menggunakan perangkat lunak yang disebut sistem manajemen database (DBMS) untuk menyimpan, mengambil, dan mengedit data. Dalam sistem komputer, _database_ kata juga dapat merujuk ke DBMS apa pun, ke sistem database, atau ke aplikasi yang terkait dengan database.
Data-data dalam basis data dikategorikan menjadi [[Model Data]]. 
Komponen Sistem Basis Data
1. [[DBMS]]
2. User
3. Basis Data
4. Sistem Operasi
5. Perangkat Keras