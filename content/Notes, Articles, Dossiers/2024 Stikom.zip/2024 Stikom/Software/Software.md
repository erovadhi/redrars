Software, atau perangkat lunak, adalah sekumpulan data yang diprogram, disimpan, dan diformat secara digital untuk menjalankan program atau perintah di dalam komputer. Software tidak memiliki bentuk fisik, tetapi dapat dioperasikan melalui perangkat komputer.

Jenis-jenis software
1. [[Operating System]]
2. [[System]]
3. [[Application]]
4. [[Malware]]