[[Karunya's Hardware Notes]]

Hardware, atau perangkat keras, adalah semua bagian fisik komputer yang dapat dilihat dan dipegang, seperti CPU, RAM, hard drive, keyboard, dan layar komputer. Hardware adalah dasar dari komputer dan merupakan komponen penting dalam pengoperasiannya. Tanpa hardware yang tepat, perangkat lunak (software) tidak akan memiliki platform untuk berjalan.

Jenis-jenis hardware:
1. [[Input Device]]
2. [[Output Device]]
3. [[Processing Device]]
4. [[Storage Device]]
5. 