XAMPP merupakan **media atau web server localhost yang bisa digunakan secara offline**. Melalui XAMPP, pengguna dapat mengelola database yang berada di localhost tanpa memerlukan akses internet sehingga jika koneksi internet terganggu dan tidak dapat mengakses web server, pengguna tidak lagi perlu khawatir.

tempat penyimpanan file PHP yang benar adalah 
Localdisk C > xampp > htdocs > buat_folder > file PHP

Pemanggilan alamat file PHP yang benar adalah localhost/folder_name>enter
